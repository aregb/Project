#!/usr/bin/env python
import serial
import sys
import time
import serial.tools.list_ports
from system.settings import SERIAL_BAUD_RATE, LEDS_TOTAL
import system.settings as settings

def lca2indexedarray(led_color_array):
    indexedarray = bytearray()
    totelements = 0
    for i in range(0,settings.LEDS_TOTAL*3,3):
        if (    led_color_array[i] ==0
            and led_color_array[i +1] == 0
            and led_color_array[i +2] ==0):
            pass
        else:
            """ if index ==0:
                indexedarray.append("0")
                indexedarray.append("0")
            #split index(address) and append in indexedarray
            else: """
            indexedarray.append(((i/3)>>8)& 0xff)
            indexedarray.append((i/3) & 0xff)
            #set color-data
            indexedarray.append(led_color_array[i])
            indexedarray.append(led_color_array[i+1])
            indexedarray.append(led_color_array[i+2])
            totelements+=1
    print("indexedarray, first five elements:")
    #add number of total elements at beginning of array
    #indexedarray.insert(0,(totelements>>8)&0xfff)
    #indexedarray.insert(1,totelements & 0xff)
    print(indexedarray[0])
    print(indexedarray[1])
    print(indexedarray[2])
    print(indexedarray[3])
    print(indexedarray[4])

    print(indexedarray)
    return indexedarray


class SerialInterface:
    def __init__(self):
        port = "/dev/ttyACM0" #hardcoded to get right port
    	#port = self._find_arduino_port()
        if port is None:
            sys.exit("Couldn't find arduino port")
        # Initialize serial communication, 8 data bits, no parity 1 stop bit
        self.ser = serial.Serial(port, SERIAL_BAUD_RATE, serial.EIGHTBITS, serial.PARITY_NONE, serial.STOPBITS_ONE)
        time.sleep(2)

    def _find_arduino_port(self):
        ports = list(serial.tools.list_ports.comports())
        for port in ports:
            if "arduino" in str(port).lower():
                return str(port).split(" -")[0]
            else:
                return None

    # Included for completeness, not actually used in our program
    def read(self, num_bytes):
        return self.ser.read(num_bytes)

    def running(self):
        return True
    
    def shutdown(self):
        self.ser.write(bytearray([0] * (3*LEDS_TOTAL)))


    def reset(self):
        print("resetting arduino")
        self.ser.write("a")
        


    def refresh(self, led_color_array):
        #indexedarray = lca2indexedarray(led_color_array)
        #print("printing whole indexed array:")
        """for i in range(settings.LEDS_TOTAL):
            if((i%10)==0 and i>0):
                print led_color_array[i*3],
                print led_color_array[i*3 +1],
                print led_color_array[i*3 +2]
            else:
                print led_color_array[i*3 ],
                print led_color_array[i*3 +1],
                print led_color_array[i*3 +2],"""
            


        """ indexedarray = bytearray([0]*(11))
        indexedarray.append("0")
        indexedarray.append("1")
        indexedarray.append("10")
        indexedarray.append("10")
        indexedarray.append("10")
        indexedarray.append("10")
        indexedarray.append("0")
        indexedarray.append("3")
        indexedarray.append("30")
        indexedarray.append("30")
        indexedarray.append("30")
        for i in range(len(indexedarray)):
            print (indexedarray[i]) """
        #self.ser.write(indexedarray)
        
        self.ser.write(led_color_array)


# This is just a testing function setting all leds to red
if __name__ == '__main__':
    testdata1 = bytearray([255, 0, 0] * 240)
    conn = SerialInterface()
    conn.refresh(testdata1)
    time.sleep(1)

